# Conducting Scores

## The Derivation of an AI-Native Organisational Construct

This bundle contains the foundational concept of the **Conducting Score**.

### Definition

A **Conducting Score** is the authoritative operational specification that coordinates people, AI agents, systems, and processes to achieve defined outcomes. It translates strategic intent into adaptive, measurable and continuously improvable execution while providing the foundation for governance, assurance and organisational learning.

## Core Concepts

- Human Conducted
- AI Assisted
- Evidence Driven
- Continuously Assured
- Living Operational Specification

## Organisational Hierarchy

```text
Institute Manual
    └── Conducting Areas
            └── Conducting Scores
                    ├── Policies
                    ├── Standards
                    ├── Procedures
                    ├── Projects
                    ├── AI Agents
                    ├── Controls
                    ├── Metrics
                    └── Evidence
```

A Conducting Score is a new organisational primitive for the Intelligence Age.
