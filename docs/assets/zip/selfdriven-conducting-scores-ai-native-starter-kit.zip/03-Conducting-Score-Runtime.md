# Conducting Score Runtime Specification

## Vision

A Conducting Score is not a document but a living digital object interpreted by a Conducting Engine.

## Canonical Model

```yaml
identity:
purpose:
outcomes:
participants:
decisions:
activities:
risks:
controls:
evidence:
metrics:
recommendations:
learning:
health:
```

## Engine Responsibilities

1. Load Conducting Score
2. Resolve participants
3. Monitor events
4. Trigger workflows
5. Enforce governance
6. Collect evidence
7. Update metrics
8. Recommend actions
9. Escalate when human judgement is required

## Generated Views

- Executive Dashboard
- Kanban Board
- Project Plan
- Risk Register
- ISO Evidence
- SOC 2 Evidence
- Audit Report
- AI Briefing
