# Project Conducting Score Template

## Identity

- Project Name:
- Conducting Area:
- Human Conductor:
- AI Steward:
- Sponsor:
- Status:

## Purpose

## Desired Outcomes

## Principles

- Human Conducted
- AI Assisted
- Evidence Driven

## Participants

### Humans

### AI Agents

### Systems

## Decision Authority

## Deliverables

## Risks

## Controls

- ISO 9001
- ISO/IEC 27001
- ISO/IEC 42001
- ISO 22301
- ISO 31000
- SOC 2

## Evidence

## Metrics

## Continuous Improvement

## Completion Criteria
